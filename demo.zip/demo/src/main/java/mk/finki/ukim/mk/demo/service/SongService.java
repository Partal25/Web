package mk.finki.ukim.mk.demo.service;

import mk.finki.ukim.mk.demo.model.Album;
import mk.finki.ukim.mk.demo.model.Artist;
import mk.finki.ukim.mk.demo.model.Song;

import java.util.List;
import java.util.Optional;

public interface SongService {
    List<Song> listSongs();
    Artist addArtistToTheSong(Artist artist, Song song);
    Song findByTrackId(Long trackId);
    public Optional<Song> save(String title, String genre, Integer releaseYear, Album album);
    void deleteById(Long id);
}
