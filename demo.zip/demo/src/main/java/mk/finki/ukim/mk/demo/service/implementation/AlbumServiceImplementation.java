package mk.finki.ukim.mk.demo.service.implementation;

import mk.finki.ukim.mk.demo.model.Album;
import mk.finki.ukim.mk.demo.repository.AlbumRepository;
import mk.finki.ukim.mk.demo.service.AlbumService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AlbumServiceImplementation implements AlbumService {
    private final AlbumRepository albumRepository;

    public AlbumServiceImplementation() {
        albumRepository = new AlbumRepository();
    }

    @Override
    public List<Album> findAll() {
        return albumRepository.findAll();
    }

    @Override
    public Optional<Album> findById(Long albumId) {
        return albumRepository.findAlbumById(albumId);
    }


}
