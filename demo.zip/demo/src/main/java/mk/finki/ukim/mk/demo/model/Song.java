package mk.finki.ukim.mk.demo.model;

import lombok.Data;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import java.util.ArrayList;
import java.util.List;

@Getter
@Data
@NoArgsConstructor
public class Song {
    private Long trackId;
    String title;
    String genre;
    Integer releaseYear;
    private List<Artist> performers;
    private Album album;

    public Song(String title, String genre, Integer releaseYear, Album album) {
        this.trackId = (long) (Math.random()*1000);

        this.title = title;
        this.genre = genre;
        this.releaseYear = releaseYear;
        performers = new ArrayList<>();
        this.album = album;
    }

    public void addArtist(Artist performer){
        performers.add(performer);
    }
}